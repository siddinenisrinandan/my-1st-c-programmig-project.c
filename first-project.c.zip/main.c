#include <stdio.h>
int main()
{
    int num1;
    int num2;
    int num3;
    printf("enter 1st number=");
    scanf("%d",&num1);
    printf("enter 2nd number=");
    scanf("%d",&num2);
    printf("enter 3rd number=");
    scanf("%d",&num3);
    if(num1<num2 && num1<num3){
        printf("%d is less ",num1);
    }
    else if(num2<num1 && num2<num3){
        printf("%d is less",num2);
    }
    else if(num3<num1 && num3<num2){
        printf("%d is less",num3);
    }
   else  if (num1==num2 && num1,num2>num3){
        printf("%d is less",num3);
    }
    else if(num2==num3 && num2,num3>num1){
        printf("%d is less",num1);
    }
    else if(num3==num1 && num3,num1>num2){
        printf("%d is less",num3);
    }
    else{
        printf("all are same");
    }
    
    return 0;
}
 